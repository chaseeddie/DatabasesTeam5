# forms.py

from wtforms import Form, StringField, SelectField


class SearchForm(Form):
    choices = [('Artist', 'Artist'),
               ('Album', 'Album'),
               ('Publisher', 'Publisher')]
    select = SelectField('Search by:', choices=choices)
    search = StringField('')