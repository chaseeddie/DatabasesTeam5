<?php
/*
 * Script to update song record.
 * Takes json object with full update of record
 */

include_once('config.php');
include_once('dbutils.php');



// get data from form
$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$name = $data['name'];
$reyear = $data['reyear'];
$title = $data['title'];
$video = $data['video'];

// connect to the database
$db = connectDB($DBHost, $DBUser, $DBPassword, $DBName);


// variable to keep track if the form is complete (set to false if there are any issues with data)
$isComplete = true;

// error message we'll give user in case there are issues with data
$errorMessage = "";

// check each of the required variables in the table
if (!isset($name) || (strlen($name) == 0)) {
    $errorMessage .= "Please enter a name.\n";
    $isComplete = false;
}

if (!isset($title) || (strlen($title)==0)) {
    $errorMessage .= "Please enter a song title.\n";
    $isComplete = false;
}

if (!isset($video) || (strlen($video)==0)) {
    $errorMessage .= "Please enter the code to embed the video.\n";
    $isComplete = false;
}


if (!isset($reyear)) {
    $errorMessage .= "Please enter a release year.\n";
    $isComplete = false;
} else if ($reyear < 1850 || $reyear > 2017) {
    $errorMessage .="Please enter a release year (four digits).\n";
    $isComplete = false;
}

if (!isset($id)) {
    // if no id was passed, then we fail
    $errorMessage .= "No id was sent.  ";
    $isComplete = false;
} else {
    // check if the id is in the table
    $query = "SELECT * FROM song WHERE id=$id";
    
    // run the query
    $result = queryDB($query, $db);
    
    if(nTuples($result) == 0) {
        $errorMessage .= "The id provided, $id does not match any ids of songs in the table.  ";
        $isComplete = false;
    }
}


// check if a song with the same name, song title, and release year is in the database
// as long as it's not the same id
// but only if we have all the data
if ($isComplete) {
    // this select statement returns any records in the song table that match the name, title, and reyear entered by the user
    $query = "SELECT * FROM song WHERE name='$name' AND title='$title' AND reyear=$reyear AND id<>$id";
    
    // run the select statement
    $result = queryDB($query, $db);
    
    // check if there is a duplicate
    if (nTuples($result) > 0) {
        // there is a duplicate
        $isComplete = false;
        $errorMessage .= "A song with name: $name, title: $title, and  reyear: $reyear is already in the database. ";
    }
}


// Stop execution and show error if the form is not complete
if($isComplete) {
    // if everything required is complete        
            
    // make video string safe
    $video = makeStringSafe($db, $video);
    
    //
    // first enter record into song table
    //
    // put together SQL statement to insert new record
    $query = "UPDATE song SET name='$name', title='$title', video='$video', reyear=$reyear WHERE id=$id";
    
    // run the insert statement
    $result = queryDB($query, $db);
    
    // send response back
    $response = array();
    $response['status'] = 'success';
    $response['id'] = $soid;
    header('Content-Type: application/json');
    echo(json_encode($response));
        
} else {
    ob_start();
    var_dump($data);
    $postdump = ob_get_clean();

    $response = array();
    $response['status'] = 'error';
    $response['message'] = $errorMessage . $postdump;
    header('Content-Type: application/json');
    echo(json_encode($response));
}

?>
