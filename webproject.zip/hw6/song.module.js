(function () {
    'use strict';
    angular.module("song", []);
})();
