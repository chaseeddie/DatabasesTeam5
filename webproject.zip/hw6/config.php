<?php
//site configuration

//Server informtion
$Proto = "http://";
$Host = $_SERVER['SERVER_NAME'];

// where we put images
$imagesDir = "images/";

//DB connection (from mysql_db_info file).
$DBUser = "zenelson";
$DBName = "db_zenelson";
$DBHost = "dbdev.cs.uiowa.edu";
$DBPassword = "vjTh-=Ed1664";
?>