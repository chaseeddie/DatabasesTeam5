--Drop the table if it already exists
DROP TABLE IF EXISTS song;

--This is a table for great music
CREATE TABLE song (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    title VARCHAR(120) NOT NULL,
    reyear INT UNSIGNED NOT NULL,
    video VARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);
    
--insert some records
INSERT INTO song (name, title, reyear, video) VALUES ('Stevie Wonder', 'Sir Duke', 1976, '<iframe src="https://www.youtube.com/embed/s6fPN5aQVDI" frameborder="0" allowfullscreen></iframe>');
INSERT INTO song (name, title, reyear, video) VALUES ('Muse', 'Butterflies and Hurricanes', 2003, '<iframe src="https://www.youtube.com/embed/YDsLKEado_o" frameborder="0" allowfullscreen></iframe>');
INSERT INTO song (name, title, reyear, video) VALUES ('Chega de Saduade', 'Joao Gilberto', 1959, '<iframe src="https://www.youtube.com/embed/yUuJrpP0Mak" frameborder="0" allowfullscreen></iframe>');
INSERT INTO song (name, title, reyear, video) VALUES ('Regina Spektor', 'End of Thought', 2016, '<iframe src="https://www.youtube.com/embed/uWTLo2kgRcw" frameborder="0" allowfullscreen></iframe>');
INSERT INTO song (name, title, reyear, video) VALUES ('Men Without Hats', 'Safety Dance',1982, '<iframe src="https://www.youtube.com/embed/nM4okRvCg2g" frameborder="0" allowfullscreen></iframe>');
