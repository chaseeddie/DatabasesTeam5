<?php
$myString = 'hello world';
var_dump($myString);
?>
<br/>
<br/>

<?php
$myString = 45;
var_dump($myString);
?>
<br/>
<br/>
<?php
echo "this is a number: " . $myString . "<br/>";
echo "this is a number: $myString <br/>";
?>